package com.ecommerce;

public class DatabaseConnection {

}
